import Reveal from '../../pages/Reveal';

export default function RevealExample() {
  return <Reveal />;
}
