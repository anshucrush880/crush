import { Router } from 'wouter';
import Ready from '../../pages/Ready';

export default function ReadyExample() {
  return (
    <Router>
      <Ready />
    </Router>
  );
}
