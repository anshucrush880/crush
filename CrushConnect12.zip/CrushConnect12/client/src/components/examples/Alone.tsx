import { Router } from 'wouter';
import Alone from '../../pages/Alone';

export default function AloneExample() {
  return (
    <Router>
      <Alone />
    </Router>
  );
}
