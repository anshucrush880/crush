import BlushingCat from '../BlushingCat';

export default function BlushingCatExample() {
  return <BlushingCat />;
}
