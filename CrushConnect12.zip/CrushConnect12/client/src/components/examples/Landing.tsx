import { Router } from 'wouter';
import Landing from '../../pages/Landing';

export default function LandingExample() {
  return (
    <Router>
      <Landing />
    </Router>
  );
}
