import { Router } from 'wouter';
import LikeMe from '../../pages/LikeMe';

export default function LikeMeExample() {
  return (
    <Router>
      <LikeMe />
    </Router>
  );
}
