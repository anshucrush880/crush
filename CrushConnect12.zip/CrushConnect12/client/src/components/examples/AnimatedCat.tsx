import AnimatedCat from '../AnimatedCat';

export default function AnimatedCatExample() {
  return <AnimatedCat />;
}
